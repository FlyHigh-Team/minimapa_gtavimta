--[[
    Minimapa GPS - estilo navegador (rua no topo, card de instrução, mapa escuro com rota).

    Comandos:
      /minimapa           liga/desliga o minimapa
      /configmapa  (F6)   abre as configurações (tamanho, formato, opacidade)
      /gps x y [z]        define destino por coordenadas
      /limpargps          remove o destino
    F11 (mapa) + botão direito do mouse = marcar destino.

    Exports (client):
      setDestination(x, y, z)   define destino (rota calculada pelas ruas, respeitando mão única)
      clearDestination()
      setRoute(points)          rota manual: { {x, y}, {x, y}, ... } ou { {x=, y=}, ... }
      getDestination()          -> x, y, z ou false
]]

------------------------------------------------------------------------
-- Configuração fixa
------------------------------------------------------------------------
local CFG = {
    margin       = 20,
    gap          = 6,
    streetHeight = 34,
    cardHeight   = 64,
    radius       = 12,

    -- tamanho base de cada formato (1080p, tamanho 100%)
    shapes = {
        round  = { w = 240, h = 240, playerY = 0.60 },
        square = { w = 240, h = 240, playerY = 0.65 },
        rect   = { w = 300, h = 210, playerY = 0.68 },
    },

    units        = "metric", -- "metric" (m/km) ou "imperial" (pés/mi)

    zoomNear     = 1.10,     -- pixels por metro parado
    zoomFar      = 0.50,     -- pixels por metro em alta velocidade
    zoomSpeed    = 160,      -- km/h em que o zoom fica no máximo afastado

    -- cores {r, g, b, a}
    routeGlow    = { 140, 30, 85 },
    routeColor   = { 255, 70, 150 },
    routeCore    = { 255, 175, 210 },
    destColor    = { 255, 70, 150 },
    accentColor  = { 236, 60, 140, 245 },
    cardColor    = { 38, 42, 50, 240 },
    streetColor  = { 28, 31, 38, 235 },
    borderColor  = { 255, 255, 255, 55 },
    mapBgColor   = { 22, 26, 32, 255 },

    arriveDistance  = 25,    -- metros para considerar "chegou"
    rerouteDistance = 60,    -- metros fora da rota para recalcular

    settingsKey  = "F6",
    settingsFile = "@minimapa_config.json", -- '@' = arquivo privado do jogador
}

-- Preferências do jogador (salvas em arquivo)
local DEFAULTS = { size = 1.0, shape = "rect", opacity = 1.0 }
local prefs = { size = DEFAULTS.size, shape = DEFAULTS.shape, opacity = DEFAULTS.opacity }

------------------------------------------------------------------------
-- Estado / recursos
------------------------------------------------------------------------
local sx, sy = guiGetScreenSize()
local S = math.max(0.7, sy / 1080)
local function sc(v) return math.floor(v * S + 0.5) end

-- valores de layout (recalculados por applyLayout)
local K, W, MH, SH, CH, GAP, R, MARGIN, PLAYER_Y

local enabled = true
local zoom = CFG.zoomNear
local lastTick = getTickCount()
local route = nil
local cursorByUs = false
local mapWasVisible = false

local mapTex, shMapTex, rt
local shMap, shMapBorder, shCard, shAccent, shStreet, shStreetBorder
local blipTex = {}

local FONT_B = "default-bold"
local FONT_R = "default"

------------------------------------------------------------------------
-- Utilitários
------------------------------------------------------------------------
local function col(t, mul)
    return tocolor(t[1], t[2], t[3], (t[4] or 255) * (mul or 1))
end

local function newRounded(w, h, r, tex)
    local sh = dxCreateShader("files/mask.fx")
    if not sh then return false end
    dxSetShaderValue(sh, "gSize", w, h)
    dxSetShaderValue(sh, "gRadius", r)
    dxSetShaderValue(sh, "gUseTex", tex and 1 or 0)
    if tex then dxSetShaderValue(sh, "gTexture", tex) end
    return sh
end

local function drawRounded(sh, x, y, w, h, color, resize)
    if sh then
        if resize then dxSetShaderValue(sh, "gSize", w, h) end
        dxDrawImage(x, y, w, h, sh, 0, 0, 0, color)
    else
        dxDrawRectangle(x, y, w, h, color)
    end
end

local function fmtDist(m)
    if CFG.units == "imperial" then
        local ft = m * 3.281
        if ft < 1000 then
            return string.format("%d pés", math.floor(ft / 10 + 0.5) * 10)
        end
        return (string.format("%.2f mi", m / 1609.34):gsub("%.", ","))
    end
    if m < 1000 then
        return string.format("%d m", math.floor(m / 10 + 0.5) * 10)
    end
    return (string.format("%.1f km", m / 1000):gsub("%.", ","))
end

local function clamp(v, a, b) return math.max(a, math.min(b, v)) end

local function normAngle(a) -- radianos, -pi..pi
    while a > math.pi do a = a - 2 * math.pi end
    while a < -math.pi do a = a + 2 * math.pi end
    return a
end

local function distToSegment(px, py, a, b)
    local dx, dy = b.x - a.x, b.y - a.y
    local len2 = dx * dx + dy * dy
    local t = 0
    if len2 > 0 then t = clamp(((px - a.x) * dx + (py - a.y) * dy) / len2, 0, 1) end
    local cx, cy = a.x + dx * t, a.y + dy * t
    return math.sqrt((px - cx) ^ 2 + (py - cy) ^ 2), t
end

local function getBlipTexture(icon)
    if blipTex[icon] == nil then
        local file = icon == 0 and "files/blips/square.png" or string.format("files/blips/%02d.png", icon)
        blipTex[icon] = fileExists(file) and dxCreateTexture(file, "argb", false, "clamp") or false
    end
    return blipTex[icon]
end

-- Mantém um ponto (coordenadas do render target) dentro do formato do minimapa
local function clampToShape(x, y, inset)
    if prefs.shape == "round" then
        local cx, cy = W / 2, MH / 2
        local dx, dy = x - cx, y - cy
        local d, r = math.sqrt(dx * dx + dy * dy), W / 2 - inset
        if d > r and d > 0 then return cx + dx / d * r, cy + dy / d * r, true end
        return x, y, false
    end
    local nx, ny = clamp(x, inset, W - inset), clamp(y, inset, MH - inset)
    return nx, ny, (nx ~= x or ny ~= y)
end

------------------------------------------------------------------------
-- Layout (tamanho / formato)
------------------------------------------------------------------------
local function destroyIf(e) if e and isElement(e) then destroyElement(e) end end

local function applyLayout()
    local shape = CFG.shapes[prefs.shape] or CFG.shapes.rect
    K = S * prefs.size
    W, MH = math.floor(shape.w * K + 0.5), math.floor(shape.h * K + 0.5)
    PLAYER_Y = shape.playerY
    SH, CH = math.floor(CFG.streetHeight * K + 0.5), math.floor(CFG.cardHeight * K + 0.5)
    GAP, MARGIN = sc(CFG.gap), sc(CFG.margin)
    R = prefs.shape == "round" and W / 2 or math.floor(CFG.radius * K + 0.5)
    local rCard = math.floor(CFG.radius * K + 0.5)

    for _, e in ipairs({ rt, shMap, shMapBorder, shCard, shAccent, shStreet, shStreetBorder }) do destroyIf(e) end

    rt = dxCreateRenderTarget(W, MH, true)
    shMap          = rt and newRounded(W, MH, R, rt)
    shMapBorder    = newRounded(W + 4, MH + 4, R + 2)
    shCard         = newRounded(W, CH, rCard)
    shAccent       = newRounded(CH, CH, rCard)
    shStreet       = newRounded(W, SH, SH / 2)
    shStreetBorder = newRounded(W, SH + 2, SH / 2 + 1)
end

local function savePrefs()
    if fileExists(CFG.settingsFile) then fileDelete(CFG.settingsFile) end
    local f = fileCreate(CFG.settingsFile)
    if f then
        fileWrite(f, toJSON(prefs))
        fileClose(f)
    end
end

local function loadPrefs()
    if not fileExists(CFG.settingsFile) then return end
    local f = fileOpen(CFG.settingsFile, true)
    if not f then return end
    local data = fromJSON(fileRead(f, fileGetSize(f)) or "")
    fileClose(f)
    if type(data) ~= "table" then return end
    if tonumber(data.size) then prefs.size = clamp(tonumber(data.size), 0.6, 1.6) end
    if tonumber(data.opacity) then prefs.opacity = clamp(tonumber(data.opacity), 0.2, 1) end
    if CFG.shapes[data.shape] then prefs.shape = data.shape end
end

------------------------------------------------------------------------
-- Rota
------------------------------------------------------------------------
local function pointAtCum(pts, cum, c)
    local n = #pts
    if c <= 0 then return pts[1].x, pts[1].y end
    if c >= cum[n] then return pts[n].x, pts[n].y end
    local lo, hi = 1, n
    while hi - lo > 1 do
        local mid = math.floor((lo + hi) / 2)
        if cum[mid] <= c then lo = mid else hi = mid end
    end
    local seg = cum[hi] - cum[lo]
    local t = seg > 0 and (c - cum[lo]) / seg or 0
    return pts[lo].x + (pts[hi].x - pts[lo].x) * t, pts[lo].y + (pts[hi].y - pts[lo].y) * t
end

local function detectTurns(pts, cum)
    local turns, LOOK = {}, 18
    local lastCum = -math.huge
    for i = 2, #pts - 1 do
        local ax, ay = pointAtCum(pts, cum, cum[i] - LOOK)
        local bx, by = pointAtCum(pts, cum, cum[i] + LOOK)
        local ix, iy = pts[i].x - ax, pts[i].y - ay
        local ox, oy = bx - pts[i].x, by - pts[i].y
        local ang = math.deg(math.atan2(ix * oy - iy * ox, ix * ox + iy * oy))
        local a = math.abs(ang)
        if a > 40 then
            local dir = a > 150 and "uturn" or (ang > 0 and "left" or "right")
            local t = { cum = cum[i], dir = dir, a = a }
            if #turns > 0 and cum[i] - lastCum < LOOK * 2 then
                if a > turns[#turns].a then turns[#turns] = t end
            else
                turns[#turns + 1] = t
            end
            lastCum = cum[i]
        end
    end
    return turns
end

local function buildRoute(pts)
    local cum = { 0 }
    for i = 2, #pts do
        cum[i] = cum[i - 1] + math.sqrt((pts[i].x - pts[i - 1].x) ^ 2 + (pts[i].y - pts[i - 1].y) ^ 2)
    end
    route.pts, route.cum, route.turns, route.idx = pts, cum, detectTurns(pts, cum), 1
end

local function normalizePoints(list)
    local pts = {}
    for _, p in ipairs(list) do
        local x, y = p.x or p[1], p.y or p[2]
        if tonumber(x) and tonumber(y) then pts[#pts + 1] = { x = tonumber(x), y = tonumber(y) } end
    end
    return pts
end

local function recalcRoute()
    if not route or route.custom then return end
    local r = route
    local el = getPedOccupiedVehicle(localPlayer) or localPlayer
    local px, py = getElementPosition(el)
    local _, _, rz = getElementRotation(el)
    local d = r.dest
    r.lastCalc = getTickCount()
    if not r.pts then
        -- enquanto calcula, mostra linha reta
        r.direct = true
        buildRoute({ { x = px, y = py }, { x = d.x, y = d.y } })
    end
    r.calculating = true
    GPS_findPath(px, py, math.rad(-rz), d.x, d.y, function(pts)
        if route ~= r then return end -- destino mudou nesse meio tempo
        r.calculating = false
        r.lastCalc = getTickCount()
        if pts and #pts > 0 then
            pts[#pts + 1] = { x = d.x, y = d.y }
            r.direct = false
            buildRoute(pts)
            r.startOff = math.sqrt((pts[1].x - px) ^ 2 + (pts[1].y - py) ^ 2)
        elseif r.direct then
            r.noPath = true
        end
    end)
end

function clearDestination()
    if route and isElement(route.blip) then destroyElement(route.blip) end
    route = nil
    return true
end

function setDestination(x, y, z)
    x, y = tonumber(x), tonumber(y)
    if not x or not y then return false end
    z = tonumber(z)
    if not z then
        local gz = getGroundPosition(x, y, 1000)
        z = (gz and gz ~= 0) and gz or 20
    end
    clearDestination()
    route = { dest = { x = x, y = y, z = z }, custom = false }
    route.blip = createBlip(x, y, z, 41, 2, 255, 255, 255, 255, 0, 99999)
    recalcRoute()
    return true
end

function setRoute(points)
    if type(points) ~= "table" then return false end
    local pts = normalizePoints(points)
    if #pts < 2 then return false end
    local last = pts[#pts]
    clearDestination()
    route = { dest = { x = last.x, y = last.y, z = 20 }, custom = true, direct = false }
    route.blip = createBlip(last.x, last.y, 20, 41, 2, 255, 255, 255, 255, 0, 99999)
    buildRoute(pts)
    return true
end

function getDestination()
    if not route then return false end
    return route.dest.x, route.dest.y, route.dest.z
end

-- Atualiza progresso na rota e devolve: restante, distância até a próxima manobra, tipo de manobra
local function updateRoute(px, py, headingRad)
    if route.direct then
        route.pts[1].x, route.pts[1].y = px, py
        local d = route.dest
        local dist = math.sqrt((d.x - px) ^ 2 + (d.y - py) ^ 2)
        route.cum[2] = dist
        local rel = normAngle(math.atan2(d.x - px, d.y - py) - headingRad)
        return dist, dist, "direct", rel
    end

    local pts, cum = route.pts, route.cum
    local best, bestD, bestT = route.idx, math.huge, 0
    for i = math.max(1, route.idx - 5), math.min(#pts - 1, route.idx + 40) do
        local d, t = distToSegment(px, py, pts[i], pts[i + 1])
        if d < bestD then best, bestD, bestT = i, d, t end
    end
    route.idx = best

    local limit = math.max(CFG.rerouteDistance, (route.startOff or 0) + 30)
    if bestD > limit and not route.custom and not route.calculating and getTickCount() - (route.lastCalc or 0) > 3000 then
        recalcRoute() -- assíncrono: continua mostrando a rota antiga até a nova chegar
    end

    local along = cum[best] + (cum[best + 1] - cum[best]) * bestT
    local remaining = (cum[#pts] - along) + bestD
    for _, t in ipairs(route.turns) do
        if t.cum > along + 2 then
            return remaining, t.cum - along, t.dir
        end
    end
    return remaining, remaining, "straight"
end

------------------------------------------------------------------------
-- Desenho de ícones
------------------------------------------------------------------------
local ARROWS = {
    straight = { line = { { 0, 0.42 }, { 0, -0.12 } }, tip = { 0, -0.42 } },
    right    = { line = { { -0.22, 0.42 }, { -0.22, -0.05 }, { 0.12, -0.05 } }, tip = { 0.42, -0.05 } },
    left     = { line = { { 0.22, 0.42 }, { 0.22, -0.05 }, { -0.12, -0.05 } }, tip = { -0.42, -0.05 } },
    uturn    = { line = { { 0.2, 0.42 }, { 0.2, -0.12 }, { 0.1, -0.3 }, { -0.1, -0.3 }, { -0.2, -0.12 }, { -0.2, 0.05 } }, tip = { -0.2, 0.38 } },
}

local function drawArrowIcon(kind, cx, cy, size, color, angle, bgColor)
    if kind == "arrive" then
        dxDrawCircle(cx, cy, size * 0.32, 0, 360, color, color, 32)
        dxDrawCircle(cx, cy, size * 0.2, 0, 360, bgColor, bgColor, 32)
        dxDrawCircle(cx, cy, size * 0.1, 0, 360, color, color, 24)
        return
    end
    local def = ARROWS[kind] or ARROWS.straight
    local ca, sa = math.cos(angle or 0), math.sin(angle or 0)
    local function tr(p) -- rotaciona (horário) e escala
        return cx + (p[1] * ca - p[2] * sa) * size, cy + (p[1] * sa + p[2] * ca) * size
    end
    local w = size * 0.13
    local line = def.line
    for i = 1, #line - 1 do
        local x1, y1 = tr(line[i])
        local x2, y2 = tr(line[i + 1])
        dxDrawLine(x1, y1, x2, y2, color, w)
        if i > 1 then dxDrawCircle(x1, y1, w / 2, 0, 360, color, color, 12) end
    end
    local bx, by = tr(line[#line])
    local tx, ty = tr(def.tip)
    local dx, dy = tx - bx, ty - by
    local len = math.sqrt(dx * dx + dy * dy)
    if len > 0 then dx, dy = dx / len, dy / len end
    local hw = size * 0.24
    dxDrawPrimitive("trianglelist", false,
        { tx, ty, color },
        { bx - dy * hw, by + dx * hw, color },
        { bx + dy * hw, by - dx * hw, color })
end

local function drawPlayerArrow(ox, oy, angle, k)
    local ca, sa = math.cos(angle), math.sin(angle)
    local function v(x, y, c)
        x, y = x * k, y * k
        return { ox + x * ca - y * sa, oy + x * sa + y * ca, c }
    end
    local dark, white = tocolor(15, 20, 28, 255), tocolor(255, 255, 255, 255)
    dxDrawPrimitive("trianglelist", false, v(0, -15, dark), v(-11, 11, dark), v(0, 6, dark))
    dxDrawPrimitive("trianglelist", false, v(0, -15, dark), v(0, 6, dark), v(11, 11, dark))
    dxDrawPrimitive("trianglelist", false, v(0, -11, white), v(-7.5, 8, white), v(0, 4, white))
    dxDrawPrimitive("trianglelist", false, v(0, -11, white), v(0, 4, white), v(7.5, 8, white))
end

local function drawDestMarker(x, y, k)
    local white, pink = tocolor(255, 255, 255, 255), col(CFG.destColor)
    dxDrawCircle(x, y, 9 * k, 0, 360, white, white, 24)
    dxDrawCircle(x, y, 6.5 * k, 0, 360, pink, pink, 24)
end

------------------------------------------------------------------------
-- Render do minimapa
------------------------------------------------------------------------
local function renderMinimap()
    local now = getTickCount()
    local dt = math.min(0.1, (now - lastTick) / 1000)
    lastTick = now

    local el = getPedOccupiedVehicle(localPlayer) or localPlayer
    local px, py, pz = getElementPosition(el)
    local _, _, rz = getElementRotation(el)
    local headingRad = math.rad(-rz)                   -- horário a partir do norte

    local camX, camY, _, lookX, lookY = getCameraMatrix()
    local yaw = math.atan2(lookX - camX, lookY - camY) -- horário a partir do norte

    -- Zoom conforme velocidade (mapa maior mostra mais área, não amplia)
    local vx, vy, vz = getElementVelocity(el)
    local kmh = math.sqrt(vx * vx + vy * vy + vz * vz) * 180
    local target = CFG.zoomNear + (CFG.zoomFar - CFG.zoomNear) * clamp(kmh / CFG.zoomSpeed, 0, 1)
    zoom = zoom + (target - zoom) * math.min(1, dt * 2.5)
    local z = zoom * S

    -- Rota
    local remaining, nextDist, nextDir, directRel
    if route then
        remaining, nextDist, nextDir, directRel = updateRoute(px, py, headingRad)
        if remaining <= CFG.arriveDistance then
            route.arrivedAt = route.arrivedAt or now
            nextDir, nextDist = "arrive", 0
            if now - route.arrivedAt > 4000 then clearDestination() end
        end
    end

    local op = prefs.opacity
    local round = prefs.shape == "round"

    -- Layout (ancorado no canto inferior esquerdo)
    local mx, my = MARGIN, sy - MARGIN - MH
    local cardY = my - GAP - CH
    local streetY = (route and cardY or my) - GAP - SH

    ---------------------------------------------------------------- mapa (render target)
    local ox, oy = W / 2, MH * PLAYER_Y
    local th = -yaw
    local ct, st = math.cos(th), math.sin(th)
    local function project(wx, wy)
        local dx, dy = (wx - px) * z, -(wy - py) * z
        return ox + dx * ct - dy * st, oy + dx * st + dy * ct
    end

    dxSetRenderTarget(rt, true)
    dxDrawRectangle(0, 0, W, MH, col(CFG.mapBgColor))

    local MS = 6000 * z
    local imgX, imgY = ox - (px + 3000) * z, oy - (3000 - py) * z
    dxDrawImage(imgX, imgY, MS, MS, shMapTex or mapTex, math.deg(th),
        ox - (imgX + MS / 2), oy - (imgY + MS / 2))

    -- linha da rota (cores opacas para não "furar" o alpha do render target)
    if route and route.pts then
        local pts = route.pts
        local startI = route.direct and 1 or route.idx + 1
        local lx, ly = project(px, py)
        local maxLen, acc = (W + MH) * 2 / z, 0
        local segs = { { lx, ly } }
        for i = startI, #pts do
            local x, y = project(pts[i].x, pts[i].y)
            segs[#segs + 1] = { x, y }
            if i > startI then acc = acc + (route.cum[i] - route.cum[i - 1]) end
            if acc > maxLen then break end
        end
        local passes = {
            { col(CFG.routeGlow), 15 * K },
            { col(CFG.routeColor), 9 * K },
            { col(CFG.routeCore), 3 * K },
        }
        for _, p in ipairs(passes) do
            local c, w = p[1], p[2]
            for i = 1, #segs - 1 do
                dxDrawLine(segs[i][1], segs[i][2], segs[i + 1][1], segs[i + 1][2], c, w)
                dxDrawCircle(segs[i + 1][1], segs[i + 1][2], w / 2, 0, 360, c, c, 12)
            end
        end
    end

    -- blips
    local dim = getElementDimension(localPlayer)
    local inset = 10 * K
    for _, b in ipairs(getElementsByType("blip")) do
        local att = getElementAttachedTo(b)
        if (not route or b ~= route.blip) and att ~= localPlayer and att ~= el and getElementDimension(b) == dim then
            local bx, by = getElementPosition(att or b)
            local visDist = getBlipVisibleDistance(b) or 16383
            if (bx - px) ^ 2 + (by - py) ^ 2 <= visDist * visDist then
                local x, y = project(bx, by)
                x, y = clampToShape(x, y, inset)
                local icon = getBlipIcon(b)
                local tex = getBlipTexture(icon)
                if tex then
                    if icon == 0 then
                        local r, g, bl, a = getBlipColor(b)
                        local s = (getBlipSize(b) or 2) * 3.5 * K
                        dxDrawImage(x - s / 2, y - s / 2, s, s, tex, 0, 0, 0, tocolor(r, g, bl, a))
                    else
                        local s = 18 * K
                        dxDrawImage(x - s / 2, y - s / 2, s, s, tex)
                    end
                end
            end
        end
    end

    -- destino (bolinha rosa, presa na borda quando fora da tela)
    if route then
        local dx, dy = project(route.dest.x, route.dest.y)
        dx, dy = clampToShape(dx, dy, 12 * K)
        drawDestMarker(dx, dy, K)
    end

    drawPlayerArrow(ox, oy, headingRad - yaw, K)
    dxSetRenderTarget()

    ---------------------------------------------------------------- painel
    drawRounded(shMapBorder, mx - 2, my - 2, W + 4, MH + 4, col(CFG.borderColor, op))
    dxDrawImage(mx, my, W, MH, shMap or rt, 0, 0, 0, tocolor(255, 255, 255, 255 * op))

    -- distância total
    if route and remaining then
        local txt = fmtDist(remaining)
        local scl = 1.15 * K
        local tx, ty, align = mx + 11 * K, my + 8 * K, "left"
        if round then tx, ty, align = mx, my + MH * 0.1, "center" end
        local tx2 = round and (mx + W) or tx
        dxDrawText(txt, tx + 1, ty + 1, tx2 + 1, ty + 1, tocolor(0, 0, 0, 200 * op), scl, FONT_B, align)
        dxDrawText(txt, tx, ty, tx2, ty, tocolor(255, 255, 255, 240 * op), scl, FONT_B, align)
    end

    -- bússola (N) na borda, apontando para o norte
    do
        local nx, ny = -math.sin(yaw), -math.cos(yaw)
        local cx, cy
        if round then
            local rr = W / 2 - 14 * K
            cx, cy = mx + W / 2 + nx * rr, my + MH / 2 + ny * rr
        else
            local hw, hh = W / 2 - 14 * K, MH / 2 - 14 * K
            local t = math.min(nx ~= 0 and hw / math.abs(nx) or math.huge, ny ~= 0 and hh / math.abs(ny) or math.huge)
            cx, cy = mx + W / 2 + nx * t, my + MH / 2 + ny * t
        end
        local r = 10 * K
        local bg = tocolor(15, 18, 24, 230 * op)
        dxDrawCircle(cx, cy, r, 0, 360, bg, bg, 24)
        dxDrawText("N", cx - r, cy - r, cx + r, cy + r, tocolor(255, 255, 255, 255 * op), 0.95 * K, FONT_B, "center", "center")
    end

    -- card de instrução
    if route and nextDir then
        local accent = col(CFG.accentColor, op)
        drawRounded(shCard, mx, cardY, W, CH, col(CFG.cardColor, op))
        drawRounded(shAccent, mx + W - CH, cardY, CH, CH, accent)

        local title
        if nextDir == "arrive" then title = "Você chegou"
        elseif nextDir == "left" then title = "Vire à esquerda"
        elseif nextDir == "right" then title = "Vire à direita"
        elseif nextDir == "uturn" then title = "Faça o retorno"
        elseif nextDir == "direct" and route.calculating then title = "Calculando rota..."
        elseif nextDir == "direct" and route.noPath then title = "Sem rota pelas ruas"
        elseif nextDir == "direct" then
            local a = math.deg(directRel)
            if math.abs(a) < 30 then title = "Siga em frente"
            elseif math.abs(a) > 150 then title = "Destino atrás"
            elseif a > 0 then title = "Destino à direita"
            else title = "Destino à esquerda" end
        else title = "Siga em frente" end

        local tx = mx + 14 * K
        dxDrawText(title, tx, cardY + 9 * K, mx + W - CH - 8 * K, cardY + CH, tocolor(255, 255, 255, 255 * op), 1.35 * K, FONT_B, "left", "top", true)
        if nextDir ~= "arrive" then
            dxDrawText(fmtDist(nextDist), tx, cardY + CH - 28 * K, 0, 0, tocolor(200, 205, 215, 255 * op), 1.25 * K, FONT_R)
        end

        local icon = nextDir == "direct" and "straight" or nextDir
        drawArrowIcon(icon, mx + W - CH / 2, cardY + CH / 2, CH * 0.6, tocolor(255, 255, 255, 255 * op),
            nextDir == "direct" and directRel or 0, accent)
    end

    -- nome da rua/zona
    local street = getZoneName(px, py, pz)
    local tscl = 1.2 * K
    local tw = dxGetTextWidth(street, tscl, FONT_B)
    local pw = math.min(W, tw + 36 * K)
    local pxs = mx + (W - pw) / 2
    drawRounded(shStreetBorder, pxs - 1, streetY - 1, pw + 2, SH + 2, col(CFG.borderColor, op), true)
    drawRounded(shStreet, pxs, streetY, pw, SH, col(CFG.streetColor, op), true)
    dxDrawText(street, pxs, streetY, pxs + pw, streetY + SH, tocolor(255, 255, 255, 255 * op), tscl, FONT_B, "center", "center", true)
end

------------------------------------------------------------------------
-- Painel de configurações
------------------------------------------------------------------------
local panel = { open = false, dragging = nil }
local PW, PH = sc(440), sc(380)
local PX, PY = (sx - PW) / 2, (sy - PH) / 2
local shPanel, shBtnShape, shBtnBottom, shTrack

local SHAPE_ORDER = { { "round", "Redondo" }, { "square", "Quadrado" }, { "rect", "Retangular" } }
local SLIDERS = {
    size    = { label = "Tamanho",   min = 0.6, max = 1.6, step = 0.05, y = 96 },
    opacity = { label = "Opacidade", min = 0.2, max = 1.0, step = 0.05, y = 262 },
}

local function sliderRect(s) return PX + sc(24), PY + sc(s.y), PW - sc(48) - sc(64), sc(6) end
local function shapeBtnRect(i)
    local bw, gap = (PW - sc(48) - sc(16)) / 3, sc(8)
    return PX + sc(24) + (i - 1) * (bw + gap), PY + sc(170), bw, sc(40)
end
local function bottomBtnRect(i)
    local bw = (PW - sc(48) - sc(10)) / 2
    return PX + sc(24) + (i - 1) * (bw + sc(10)), PY + PH - sc(64), bw, sc(42)
end
local function inside(x, y, rx, ry, rw, rh) return x >= rx and x <= rx + rw and y >= ry and y <= ry + rh end

local function ensurePanelShaders()
    if shPanel then return end
    local _, _, bw, bh = shapeBtnRect(1)
    local _, _, ow, oh = bottomBtnRect(1)
    local _, _, tw, th = sliderRect(SLIDERS.size)
    shPanel     = newRounded(PW, PH, sc(16))
    shBtnShape  = newRounded(bw, bh, sc(10))
    shBtnBottom = newRounded(ow, oh, sc(10))
    shTrack     = newRounded(tw, th, th / 2)
end

local function setSlider(name, cx)
    local s = SLIDERS[name]
    local x, _, w = sliderRect(s)
    local t = clamp((cx - x) / w, 0, 1)
    local v = s.min + (s.max - s.min) * t
    v = math.floor(v / s.step + 0.5) * s.step
    v = clamp(v, s.min, s.max)
    if math.abs(v - prefs[name]) > 0.001 then
        prefs[name] = v
        if name == "size" then applyLayout() end
    end
end

local function renderPanel()
    if not panel.open then return end
    ensurePanelShaders()
    local cx, cy = getCursorPosition()
    if cx then cx, cy = cx * sx, cy * sy end
    local white, grey = tocolor(255, 255, 255, 255), tocolor(170, 176, 188, 255)
    local accent = col(CFG.accentColor, 1)

    dxDrawRectangle(0, 0, sx, sy, tocolor(0, 0, 0, 90))
    drawRounded(shPanel, PX, PY, PW, PH, tocolor(26, 29, 36, 245))
    dxDrawText("Configurações do minimapa", PX + sc(24), PY + sc(20), 0, 0, white, 1.45 * S, FONT_B)

    -- sliders
    for name, s in pairs(SLIDERS) do
        local x, y, w, h = sliderRect(s)
        local t = (prefs[name] - s.min) / (s.max - s.min)
        dxDrawText(s.label, x, y - sc(30), 0, 0, grey, 1.2 * S, FONT_B)
        drawRounded(shTrack, x, y, w, h, tocolor(60, 65, 76, 255))
        dxDrawRectangle(x + h / 2, y, math.max(0, w * t - h / 2), h, accent)
        local kx, ky = x + w * t, y + h / 2
        dxDrawCircle(kx, ky, sc(10), 0, 360, white, white, 24)
        dxDrawCircle(kx, ky, sc(6), 0, 360, accent, accent, 24)
        dxDrawText(string.format("%d%%", math.floor(prefs[name] * 100 + 0.5)), x + w + sc(12), y - sc(10), PX + PW - sc(24), y + h + sc(10),
            white, 1.25 * S, FONT_B, "right", "center")
    end

    -- formato
    dxDrawText("Formato", PX + sc(24), PY + sc(140), 0, 0, grey, 1.2 * S, FONT_B)
    for i, opt in ipairs(SHAPE_ORDER) do
        local x, y, w, h = shapeBtnRect(i)
        local selected = prefs.shape == opt[1]
        local hover = cx and inside(cx, cy, x, y, w, h)
        local bg = selected and accent or (hover and tocolor(70, 76, 88, 255) or tocolor(48, 52, 62, 255))
        drawRounded(shBtnShape, x, y, w, h, bg)
        dxDrawText(opt[2], x, y, x + w, y + h, white, 1.2 * S, FONT_B, "center", "center")
    end

    -- botões
    local labels = { "Restaurar padrão", "Salvar e fechar" }
    for i, lbl in ipairs(labels) do
        local x, y, w, h = bottomBtnRect(i)
        local hover = cx and inside(cx, cy, x, y, w, h)
        local bg = i == 2 and accent or (hover and tocolor(70, 76, 88, 255) or tocolor(48, 52, 62, 255))
        if i == 2 and hover then bg = col({ 255, 90, 160, 255 }) end
        drawRounded(shBtnBottom, x, y, w, h, bg)
        dxDrawText(lbl, x, y, x + w, y + h, white, 1.2 * S, FONT_B, "center", "center")
    end
end

local function setPanelOpen(state)
    if panel.open == state then return end
    panel.open = state
    panel.dragging = nil
    showCursor(state)
    if not state then savePrefs() end
end

local function togglePanel() setPanelOpen(not panel.open) end

addEventHandler("onClientClick", root, function(button, state, ax, ay)
    if not panel.open or button ~= "left" then return end
    if state == "up" then
        if panel.dragging then panel.dragging = nil; savePrefs() end
        return
    end
    for name, s in pairs(SLIDERS) do
        local x, y, w, h = sliderRect(s)
        if inside(ax, ay, x - sc(12), y - sc(14), w + sc(24), h + sc(28)) then
            panel.dragging = name
            setSlider(name, ax)
            return
        end
    end
    for i, opt in ipairs(SHAPE_ORDER) do
        if inside(ax, ay, shapeBtnRect(i)) then
            if prefs.shape ~= opt[1] then prefs.shape = opt[1]; applyLayout(); savePrefs() end
            playSoundFrontEnd(1)
            return
        end
    end
    if inside(ax, ay, bottomBtnRect(1)) then
        prefs.size, prefs.shape, prefs.opacity = DEFAULTS.size, DEFAULTS.shape, DEFAULTS.opacity
        applyLayout(); savePrefs(); playSoundFrontEnd(1)
    elseif inside(ax, ay, bottomBtnRect(2)) then
        playSoundFrontEnd(1)
        setPanelOpen(false)
    end
end)

addEventHandler("onClientCursorMove", root, function(_, _, ax)
    if panel.open and panel.dragging then setSlider(panel.dragging, ax) end
end)

------------------------------------------------------------------------
-- Loop principal
------------------------------------------------------------------------
local function render()
    -- Cursor no mapa F11 para marcar destino
    local mapVisible = isPlayerMapVisible()
    if mapVisible ~= mapWasVisible then
        mapWasVisible = mapVisible
        if mapVisible and not isCursorShowing() then
            showCursor(true); cursorByUs = true
        elseif not mapVisible and cursorByUs then
            showCursor(false); cursorByUs = false
        end
    end

    if (enabled or panel.open) and not mapVisible and mapTex and rt then
        renderMinimap()
    end
    renderPanel()
end

------------------------------------------------------------------------
-- Eventos / comandos
------------------------------------------------------------------------
addEventHandler("onClientResourceStart", resourceRoot, function()
    mapTex = dxCreateTexture("files/map.png", "argb", true, "clamp")
    if not mapTex then
        outputChatBox("[minimapa] Falha ao carregar a textura do mapa.", 255, 80, 80)
        return
    end
    shMapTex = dxCreateShader("files/map.fx")
    if shMapTex then dxSetShaderValue(shMapTex, "gTexture", mapTex) end

    loadPrefs()
    applyLayout()

    setPlayerHudComponentVisible("radar", false)
    addEventHandler("onClientRender", root, render)
    bindKey(CFG.settingsKey, "down", togglePanel)
end)

addEventHandler("onClientResourceStop", resourceRoot, function()
    setPlayerHudComponentVisible("radar", true)
    if cursorByUs or panel.open then showCursor(false) end
end)

-- Botão direito no mapa F11 = marcar destino
addEventHandler("onClientClick", root, function(button, state, absX, absY)
    if button ~= "right" or state ~= "down" or not isPlayerMapVisible() then return end
    local minX, minY, maxX, maxY = getPlayerMapBoundingBox()
    if not minX then return end
    local wx = (absX - minX) / (maxX - minX) * 6000 - 3000
    local wy = 3000 - (absY - minY) / (maxY - minY) * 6000
    if wx < -3000 or wx > 3000 or wy < -3000 or wy > 3000 then return end
    setDestination(wx, wy)
    playSoundFrontEnd(1)
end)

addCommandHandler("minimapa", function()
    enabled = not enabled
    setPlayerHudComponentVisible("radar", not enabled)
    outputChatBox("[minimapa] " .. (enabled and "ligado" or "desligado"), 255, 70, 150)
end)

addCommandHandler("configmapa", togglePanel)

addCommandHandler("gps", function(_, x, y, z)
    if setDestination(x, y, z) then
        outputChatBox("[minimapa] Destino definido.", 255, 70, 150)
    else
        outputChatBox("Uso: /gps x y [z]  (ou botão direito no mapa F11)", 255, 200, 0)
    end
end)

addCommandHandler("limpargps", function()
    clearDestination()
    outputChatBox("[minimapa] Destino removido.", 255, 70, 150)
end)

const fs=require('fs');
exports.load=function(dir,rule){
  const areas=[];
  for(let a=0;a<64;a++){
    const b=fs.readFileSync(`${dir}/NODES${a}.DAT`);
    const nN=b.readUInt32LE(0),nV=b.readUInt32LE(4),nNavi=b.readUInt32LE(12),nL=b.readUInt32LE(16);
    const navOff=20+nN*28, linkOff=navOff+nNavi*14, naviLinkOff=linkOff+nL*4+768;
    const nodes=[];
    for(let i=0;i<nV;i++){const o=20+i*28;nodes.push({x:b.readInt16LE(o+8),y:b.readInt16LE(o+10),z:b.readInt16LE(o+12),link:b.readUInt16LE(o+16),f:b.readUInt32LE(o+24)});}
    const navi=[];for(let i=0;i<nNavi;i++){const o=navOff+i*14;navi.push({dx:b.readInt8(o+8),dy:b.readInt8(o+9),f:b.readUInt32LE(o+10)});}
    const links=[],nlinks=[];for(let i=0;i<nL;i++){links.push([b.readUInt16LE(linkOff+i*4),b.readUInt16LE(linkOff+i*4+2)]);nlinks.push(b.readUInt16LE(naviLinkOff+i*2));}
    areas.push({nodes,navi,links,nlinks});
  }
  // global index (exclude boats)
  const G=[],idx={};
  areas.forEach((A,a)=>A.nodes.forEach((n,i)=>{if(n.f&0x80)return;idx[a*65536+i]=G.length;G.push({x:n.x,y:n.y,z:n.z,hw:(n.f>>13)&1,out:[]});}));
  let oneway=0,two=0;
  areas.forEach((A,a)=>A.nodes.forEach((n,i)=>{
    const gi=idx[a*65536+i];if(gi===undefined)return;
    for(let k=0;k<(n.f&15);k++){
      const [ta,ti]=A.links[n.link+k];const gt=idx[ta*65536+ti];if(gt===undefined)continue;
      const nl=A.nlinks[n.link+k];const N=areas[nl>>10]&&areas[nl>>10].navi[nl&1023];
      let ok=true;
      if(N){const L=(N.f>>8)&7,R=(N.f>>11)&7;
        if(L+R>0&&(L==0||R==0)){const vx=G[gt].x-G[gi].x,vy=G[gt].y-G[gi].y;const dot=vx*N.dx+vy*N.dy;
          let fwd=dot>0?R:L; if(rule==='B')fwd=dot>0?L:R; ok=fwd>0; oneway++;} else two++;}
      if(ok&&!G[gi].out.includes(gt))G[gi].out.push(gt);
    }}));
  return {G,oneway,two};
};

const fs=require('fs');const {load}=require('./lib');
const {G,oneway,two}=load(process.argv[2],'B');
// stats: reachability from a node in LS (Grove St ~ 2495,-1665)
let s=0,bd=1e18;G.forEach((n,i)=>{const d=(n.x/8-2495)**2+(n.y/8+1665)**2;if(d<bd){bd=d;s=i}});
const seen=new Uint8Array(G.length);const st=[s];seen[s]=1;let c=1;while(st.length){const u=st.pop();for(const v of G[u].out)if(!seen[v]){seen[v]=1;c++;st.push(v)}}
let edges=0;G.forEach(n=>edges+=n.out.length);
console.log({nodes:G.length,edges,oneway,two,reachableFromGrove:c});
// main SCC flag
const rev=G.map(()=>[]);G.forEach((n,u)=>n.out.forEach(v=>rev[v].push(u)));const back=new Uint8Array(G.length);const st2=[s];back[s]=1;while(st2.length){const u=st2.pop();for(const v of rev[u])if(!back[v]){back[v]=1;st2.push(v)}}
let main=0;G.forEach((n,i)=>{if(seen[i]&&back[i]){n.hw|=2;main++}});console.log("main SCC",main);
// binary: "GPN1", uint32 n, then per node: int16 x,y,z (x8), uint8 flags, uint8 cnt, uint16[cnt]
const buf=Buffer.alloc(8+G.length*8+edges*2);let o=0;buf.write('GPN1',0);o=4;buf.writeUInt32LE(G.length,o);o+=4;
for(const n of G){buf.writeInt16LE(n.x,o);buf.writeInt16LE(n.y,o+2);buf.writeInt16LE(n.z,o+4);buf.writeUInt8(n.hw,o+6);buf.writeUInt8(n.out.length,o+7);o+=8;for(const v of n.out){buf.writeUInt16LE(v,o);o+=2;}}
fs.writeFileSync(process.argv[3],buf);console.log('bytes',buf.length);

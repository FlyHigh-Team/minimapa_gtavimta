// Deixa o mapa do GTA com visual escuro/dessaturado (estilo GPS noturno).
texture gTexture;
float gSaturation = 0.25;   // 0 = cinza, 1 = cores originais
float gBrightness = 0.55;   // multiplicador de brilho
float3 gTint = float3(0.05, 0.07, 0.10);   // tom azulado somado

sampler MapSampler = sampler_state
{
    Texture   = <gTexture>;
    MinFilter = Linear;
    MagFilter = Linear;
    MipFilter = Linear;
    AddressU  = Clamp;
    AddressV  = Clamp;
};

float4 PS(float4 diffuse : COLOR0, float2 uv : TEXCOORD0) : COLOR0
{
    float4 c = tex2D(MapSampler, uv);
    float  g = dot(c.rgb, float3(0.299, 0.587, 0.114));
    float3 col = lerp(float3(g, g, g), c.rgb, gSaturation) * gBrightness + gTint;
    return float4(col, 1) * diffuse;
}

technique DarkMap
{
    pass P0
    {
        PixelShader = compile ps_2_0 PS();
    }
}

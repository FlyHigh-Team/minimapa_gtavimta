// Retangulo com cantos arredondados (anti-aliased), com ou sem textura.
texture gTexture;
float2  gSize   = float2(100, 100);   // tamanho desenhado em pixels
float   gRadius = 10;                 // raio dos cantos em pixels
float   gUseTex = 0;                  // 1 = usa gTexture, 0 = cor solida

sampler TexSampler = sampler_state
{
    Texture   = <gTexture>;
    MinFilter = Linear;
    MagFilter = Linear;
    AddressU  = Clamp;
    AddressV  = Clamp;
};

float4 PS(float4 diffuse : COLOR0, float2 uv : TEXCOORD0) : COLOR0
{
    float4 tex = tex2D(TexSampler, uv);
    float4 col = diffuse * lerp(float4(1, 1, 1, 1), tex, gUseTex);

    float2 p    = uv * gSize;
    float2 hs   = gSize * 0.5;
    float2 q    = abs(p - hs) - (hs - gRadius);
    float  d    = length(max(q, 0)) + min(max(q.x, q.y), 0) - gRadius;

    col.a *= saturate(0.5 - d);
    return col;
}

technique RoundedRect
{
    pass P0
    {
        PixelShader = compile ps_2_0 PS();
    }
}

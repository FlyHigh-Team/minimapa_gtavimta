--[[
    Pathfinding pelas ruas usando os path nodes de veículos do GTA SA
    (files/nodes.dat, gerado a partir de data/Paths/NODES*.DAT - ver tools/).

    Respeita mão única. Calcula de forma assíncrona (coroutine) para não travar o jogo.
    GPS_findPath(x1, y1, heading, x2, y2, callback)  -> callback(points ou nil)
]]

local NX, NY, NZ, FLAG, ADJ = {}, {}, {}, {}, {}
local GRID, CELL = {}, 100
local loaded = false

local HIGHWAY_FACTOR = 0.8      -- < 1 = prefere rodovias
local STEPS_PER_FRAME = 3000    -- nós expandidos por frame

local function cellKey(cx, cy) return cx * 1000 + cy end

local function u16(s, i) local a, b = s:byte(i, i + 1); return a + b * 256 end
local function i16(s, i) local v = u16(s, i); return v >= 32768 and v - 65536 or v end

local function loadNodes()
    local f = fileOpen("files/nodes.dat", true)
    if not f then outputDebugString("[minimapa] files/nodes.dat não encontrado", 1) return end
    local s = fileRead(f, fileGetSize(f))
    fileClose(f)
    if s:sub(1, 4) ~= "GPN1" then outputDebugString("[minimapa] nodes.dat inválido", 1) return end
    local n = u16(s, 5) + u16(s, 7) * 65536
    local p = 9
    for i = 1, n do
        local x, y, z = i16(s, p) / 8, i16(s, p + 2) / 8, i16(s, p + 4) / 8
        local fl, cnt = s:byte(p + 6, p + 7)
        p = p + 8
        local adj = {}
        for k = 1, cnt do adj[k] = u16(s, p) + 1; p = p + 2 end
        NX[i], NY[i], NZ[i], FLAG[i], ADJ[i] = x, y, z, fl, adj
        local key = cellKey(math.floor(x / CELL), math.floor(y / CELL))
        local c = GRID[key]
        if not c then c = {}; GRID[key] = c end
        c[#c + 1] = i
    end
    loaded = true
end

-- Nó mais próximo da rede principal. Com heading, penaliza nós atrás do jogador.
local function nearestNode(x, y, heading)
    local cx, cy = math.floor(x / CELL), math.floor(y / CELL)
    local best, bestScore
    local hx, hy = heading and math.sin(heading), heading and math.cos(heading)
    for r = 0, 6 do
        for ix = cx - r, cx + r do
            for iy = cy - r, cy + r do
                if math.max(math.abs(ix - cx), math.abs(iy - cy)) == r then
                    local c = GRID[cellKey(ix, iy)]
                    if c then
                        for _, i in ipairs(c) do
                            if FLAG[i] >= 2 then -- bit 1 = rede principal
                                local dx, dy = NX[i] - x, NY[i] - y
                                local score = math.sqrt(dx * dx + dy * dy)
                                if hx and score > 1 and (dx * hx + dy * hy) < 0 then score = score + 35 end
                                if not bestScore or score < bestScore then best, bestScore = i, score end
                            end
                        end
                    end
                end
            end
        end
        if best and bestScore < (r * CELL) then break end
    end
    return best
end

-- A* com heap binário
local function astar(s, t)
    local g, came, closed = { [s] = 0 }, {}, {}
    local heap, hf = { s }, { [s] = 0 }
    local tx, ty = NX[t], NY[t]
    local steps = 0

    local function push(v, f)
        hf[v] = f
        heap[#heap + 1] = v
        local i = #heap
        while i > 1 do
            local p = math.floor(i / 2)
            if hf[heap[p]] <= f then break end
            heap[i], heap[p] = heap[p], heap[i]
            i = p
        end
    end
    local function pop()
        local top, last = heap[1], heap[#heap]
        heap[#heap] = nil
        local n = #heap
        if n > 0 then
            heap[1] = last
            local i = 1
            while true do
                local l, r, m = i * 2, i * 2 + 1, i
                if l <= n and hf[heap[l]] < hf[heap[m]] then m = l end
                if r <= n and hf[heap[r]] < hf[heap[m]] then m = r end
                if m == i then break end
                heap[i], heap[m] = heap[m], heap[i]
                i = m
            end
        end
        return top
    end

    while #heap > 0 do
        local u = pop()
        if u == t then
            local path, c = {}, t
            while c do table.insert(path, 1, c); c = came[c] end
            return path
        end
        if not closed[u] then
            closed[u] = true
            local gu, ux, uy = g[u], NX[u], NY[u]
            for _, v in ipairs(ADJ[u]) do
                if not closed[v] then
                    local dx, dy = NX[v] - ux, NY[v] - uy
                    local w = math.sqrt(dx * dx + dy * dy)
                    if FLAG[v] % 2 == 1 and FLAG[u] % 2 == 1 then w = w * HIGHWAY_FACTOR end
                    local ng = gu + w
                    if not g[v] or ng < g[v] then
                        g[v], came[v] = ng, u
                        local hx, hy = tx - NX[v], ty - NY[v]
                        push(v, ng + math.sqrt(hx * hx + hy * hy) * HIGHWAY_FACTOR)
                    end
                end
            end
            steps = steps + 1
            if steps % STEPS_PER_FRAME == 0 then coroutine.yield() end
        end
    end
    return nil
end

local jobs = {}

addEventHandler("onClientPreRender", root, function()
    for i = #jobs, 1, -1 do
        local co = jobs[i]
        local ok, err = coroutine.resume(co)
        if not ok then outputDebugString("[minimapa] erro no GPS: " .. tostring(err), 1) end
        if coroutine.status(co) == "dead" then table.remove(jobs, i) end
    end
end)

function GPS_isLoaded() return loaded end

function GPS_findPath(x1, y1, heading, x2, y2, callback)
    if not loaded then callback(nil) return end
    jobs[#jobs + 1] = coroutine.create(function()
        local s, t = nearestNode(x1, y1, heading), nearestNode(x2, y2)
        if not s or not t then callback(nil) return end
        local path = astar(s, t)
        if not path then callback(nil) return end
        local pts = {}
        for k, i in ipairs(path) do pts[k] = { x = NX[i], y = NY[i], z = NZ[i] } end
        callback(pts)
    end)
end

addEventHandler("onClientResourceStart", resourceRoot, loadNodes)
